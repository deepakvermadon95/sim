Before submitting your pull request, be sure your code adheres to PHPMailer
coding standards by running the following command:

`./vendor/bin/php-cs-fixer fix`

And committing eventual changes.
