<?php
session_start();
include 'connection.php';
$tea_regno = $_SESSION['t_regno'];
$subject = $_GET['subject'];
$class = $_GET['class'];
$sec = $_GET['sec'];
$date = $_GET['doa'];
$i=0;
$check_before_insert = "select * from attendance where date='$date' and subject='$subject' and class='$class' and sec ='$sec' and tea_regno='$tea_regno';";
if(mysqli_num_rows(mysqli_query($con,$check_before_insert))==0)
{
    if(isset($_SESSION['num_of_students'])){
		while ($i<$_SESSION['num_of_students']) {
			$roll = $_SESSION['roll'][$i];
			if(isset($_POST["$roll"]))
			{
			     $attend = $_POST["$roll"];
			} else {
			     $attend = "A" ;
			}
			$sql = "insert into attendance values('$tea_regno','$roll','$date','$attend','$subject','$class','$sec');";
			if(mysqli_query($con,$sql))
                {
                    $_SESSION['message']="done";
                }else 
                  $_SESSION['message']="something went wrong";
			echo $_SESSION['roll'][$i]."-".$attend."<br>";
		$i++;
		}
	}
}
else{
	if(isset($_SESSION['num_of_students'])){
		while ($i<$_SESSION['num_of_students']) {
				$roll = $_SESSION['roll'][$i];
				if(isset($_POST["$roll"]))
				{
				     $attend = $_POST["$roll"];
				} else {
				     $attend = "A" ;
				}
				$sql = "update attendance set attend = '$attend' where tea_regno= '$tea_regno' and stu_regno='$roll' and date = '$date' ;";
				if(mysqli_query($con,$sql))
	                {
	                   $_SESSION['message']="done"; 
	                }else 
	                  $_SESSION['message']="something went wrong";
				echo $_SESSION['roll'][$i]."-".$attend."<br>";
				$i++;
			}
	}
}
header("Location:attendance.php?subject=$subject&class=$class&sec=$sec&doa=$date");

unset($_SESSION['roll']);
unset($_SESSION['num_of_students']);

?>

