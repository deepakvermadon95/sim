<?php
    session_start();
    include 'connection.php';
    $tea_regno = $_SESSION['t_regno'];
    $fetch_4digit_school = $tea_regno[3].$tea_regno[4].$tea_regno[5].$tea_regno[6];

    $subject = $_POST['subject'];
    $class = $_POST['class'];
    $url =$_POST['url'];
    $disc = $_POST['disc'];
    
    $check_before_insert1 = "select tea_regno from reference where subject='$subject' and class='$class' and tea_regno='$tea_regno' and link ='$url' and description='$disc';";
    $check_before_insert2 = "select tea_regno from teacher_subject where subject='$subject' and class='$class' and tea_regno='$tea_regno';";
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        
body {
    
    background-color: #D5D6D7;
   
}
.dropdown:hover > .dropdown-menu {
    display: block;
}
.dropdown > .dropdown-toggle:active {
    /*Without this, clicking will make it sticky*/
    pointer-events: none;
}

.head2{
    width: 100%;
        background-image: url(../Images/std2.jpg);
   
   background-color: #cccccc;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
.header{
    width: 100%;
    background-color: #D5D6D7;
    background:rgba(0,0,0,0.5);
    height: 100px;
    border-style: groove;
    border-radius: 8px;
     box-shadow: 0px 5px rgba(0,0,0,0.3);
    filter: alpha(opacity=10);
    text-align: center;
    border: none;

}
.head1{
    background-color: yellow;
    height: 70px;
    margin: 3px;
    padding: 15px;
}
hr{

    border:  1px solid red;
}
tr{
    text-transform: capitalize;
    background-image: url(../Images/std2.jpg);
   filter: alpha(opacity=10);
   background-color: #cccccc;
   border-style: groove;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    border-radius: 5px;
}
th{
    background-image: url(../Images/table1.jpg);
   filter: alpha(opacity=10);
   background-color: #cccccc;
   border-style: groove;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
.borderless{
    border: 0px;
    background-color: white;
}
button: hover{
    background-color: red;
}

.stdhead{
    background-color: red;
    
    height: 210px;
    border-radius: 10px;
    background:rgba(253,246,223,0.8);

     box-shadow: 0px 8px rgba(0,0,0,0.3);

}
.stdbd{
    background-image: url(../Images/bg2.jpg);
   
   background-color: #cccccc;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    background-color: #D5D6D7;
}


.searchheader{
    width: 100%;
    margin: 0px;
    background:rgba(0,0,0,0.5);
    height: 100px;
    //border-radius: 1px;
    color: white;
    padding: 20px;
    text-shadow: 4px 4px 3px #000000;
    font-weight: 40px;
}
.searchbox{
    margin-top: 10px;   
    height: 500px;
    opacity: .9;
  border: 3px solid black;




    box-shadow: 0 1px 2px 2px rgba(255,255,255,0.9);    
    //background-color: transparent;
   
  background-color:rgba(0, 0,0,0.3);  
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
input{
        width: 100%;
    height: 38px;
    border-radius: 3px;
    border-width: 1px;
    border-color:rgba(0,0,0,0.1);
    color: white;
    border-collapse: collapse;
    background:rgba(255,255,255,0.8);
    padding-left: 5px;  
}

.searchbody{
    
   
   background-color: #cccccc;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

.subbtn:hover {
    box-shadow: 5px 5px 7px rgba(0,0,0,1);
}


div.polaroid {
  width: 80%;
  background-color: white;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.4), 0 6px 20px 0 rgba(0, 0, 0, 0.3);

}

div.container1 {
  text-align: center;
  padding-top: 5px;
  padding-bottom: 1px;
 background:transparent;
}

.head{
  background: linear-gradient(10deg,#F6F6FF,#3A3838);
}
.shadow{
  position: relative;
  width: 500px;
  margin: 200px auto;
  height: 250px;
  background: linear-gradient(90deg,#080505,#A4A0A0);
  text-align: center;
}

.logo{
  margin-left: 50px;
   background: linear-gradient(10deg,#F6F6FF,#9e9da2);
}
    </style>
    <link rel="stylesheet" type="text/css" href="style.css">
   <link rel="stylesheet" type="text/css" href="../bootstrap/css/glyphicon.css">
  <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
</head>
<body style="background-color: #000;">
<?php
    if(mysqli_num_rows(mysqli_query($con,$check_before_insert1))!=0)
    {
         echo '<div class="shadow"> <h1 style="padding-top:80px; color: #fff; text-shadow: 2px 2px 4px #000000;">Entry already Exist for this Configuration</h1><br>
                    <a class="btn btn-outline-light" href="welcome_teacher.php">Back</a></div>';
        //echo "Entry already Exist for this Configuration";
        //header( "refresh:5;url=welcome_teacher.php" );
    }
    elseif (mysqli_num_rows(mysqli_query($con,$check_before_insert2))==0) {
        echo '<div class="shadow"> <h1 style="padding-top:80px; color: #fff; text-shadow: 2px 2px 4px #000000;">You have selected a wrong Configuration</h1><br>
                    <a class="btn btn-outline-light" href="welcome_teacher.php">Back</a></div>';
        //echo "You have selected a wrong Configuration";
        //header( "refresh:5;url=welcome_teacher.php" );
    }else {
    $sql = "insert into reference values('$tea_regno','$class','$disc','$url','$subject');";
        if($result=mysqli_query($con,$sql))
            header('Location:welcome_teacher.php');
        else
            echo "something went wrong";
    }
?>
</body>
</html>
