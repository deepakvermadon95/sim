
<?php
//include 'db.php';

 
if(isset($_POST['submit']))
{
    $item_id=$_POST['itemid'];
    $name=$_POST['name'];
    $quantity=$_POST['quantity'];
    $salary=$_POST['salary'];
    $price=$_POST['price'];
    $height=$_POST['height'];
    
    $weight=$_POST['weight'];
    $item_image = addslashes(file_get_contents($_FILES["item_image"]["tmp_name"])); 
    

    $sql="INSERT INTO items VALUES ('$item_id','$name',$quantity,$price,'$height',$weight,'$item_image') ";
    
    if(mysqli_query($conn,$sql))
        {
          
         echo "<script>alert('New record inserted successfully')</script>";
                 //header('location:add_item.php');
        } 
    else 
        {
            
         echo "<script>alert('Something Going Wrong, Please check you self!')</script>";
         //header('location:add_item.php');
        }
    
   
    
}

?>



 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add New Item</title>
    
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
 <script>
   function checkname()
        {
            var x=document.getElementById("name").value;
            var name=/^[A-Za-z ]{3,30}$/;
            if(name.test(x))
                {
            document.getElementById("nameerror").innerHTML="*";

                }
            else{
                 document.getElementById("nameerror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("name").value="";
                document.getElementById("name").focus();
            }
            
        }
function checkquantity()
        {
            var x=document.getElementById("quantity").value;
            var name=/^[0-9]{1,}$/;
            if(name.test(x))
                {
            document.getElementById("quantityerror").innerHTML="*";

                }
            else{
                 document.getElementById("quantityerror").innerHTML="Quantity never negative";
                document.getElementById("quantity").value="";
                document.getElementById("quantity").focus();
            }
            
        }
function checkprice()
        {
            var x=document.getElementById("price").value;
            var name=/^[1-9][0-9]{1,}[0-9.]{0,3}$/;
            
            if(name.test(x))
                {
            document.getElementById("priceerror").innerHTML="*";

                }
            else{
                 document.getElementById("priceerror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("price").value="";
                document.getElementById("price").focus();
            }
            
        }
function checkheight()
        {
            var x=document.getElementById("height").value;
            var name=/^[1-9][0-9]{0,}[-][0-9][01]{0,1}$/;
            
            if(name.test(x))
                {
            document.getElementById("heighterror").innerHTML="*";

                }
            else{
                 document.getElementById("heighterror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("height").value="";
                document.getElementById("height").focus();
            }
            
        }
function checkweight()
        {
            var x=document.getElementById("weight").value;
            var name=/^[1-9][0-9]{1,}$/;
            
            if(name.test(x))
                {
            document.getElementById("weighterror").innerHTML="*";

                }
            else{
                 document.getElementById("weighterror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("weight").value="";
                document.getElementById("weight").focus();
            }
            
        }

        function checkmobile()
        {
            var x=document.getElementById("number").value;
            var mobile=/^[6789][0-9]{9}$/;
            if(mobile.test(x))
                {
            document.getElementById("mobileerror").innerHTML="";

                }
            else{
                 document.getElementById("mobileerror").innerHTML="Wrong mobile number please check your self";
            }
            
        }
        function checkpassword()
        {
            var x=document.getElementById("password").value;
            var password=/^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,15}$/;
            if(password.test(x))
                {
            document.getElementById("passworderror").innerHTML="";

                }
            else{
                 document.getElementById("passworderror").innerHTML="there must be atleast one spacial charcter and one digits ";
                document.getElementById("password").value="";
                document.getElementById("password").focus();
            }
            
        }

function checkrepassword()
        {
            var x=document.getElementById("password").value;
            var y=document.getElementById("repassword").value;
            //var password=/^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,15}$/;
            if()
                {
            document.getElementById("passworderror").innerHTML="";

                }
            else{
                 document.getElementById("passworderror").innerHTML="there must be atleast one spacial charcter and one digits ";
                document.getElementById("password").value="";
                document.getElementById("password").focus();
            }
            
        }

        function checkmail()
        {
            
            var x=document.getElementById("email").value;
            var emailcheck=/^[a-z][a-z0-9_]{2,}@[a-z]{2,}[.][a-z.]{2,6}$/;
            if(emailcheck.test(x)){
                        document.getElementById("emailerror").innerHTML="";
                      }
            else{
                    document.getElementById("emailerror").innerHTML="wrong Email";
                    //document.getElementById("email").innerHTML="";
                    document.getElementById("email").focus();

            }
                
    
                
        }
                
            
    

 </script>
  <link rel="stylesheet" type="text/css" href="htmlform.css">
   
    
</head>
<body style="background-color:lightgray";>
 
<div class="container">
  <h1> </h1><br><br>

     <div class="panel panel-default">
        <div class="panel-heading"><h2 style="text-align:center;color:blue;">ADD NEW ITEMS</h2></div>
                <div class="panel-body">
               
                <form class="form-horizontal" action="add_item.php" method="POST" enctype="multipart/form-data" style="margin:100px;">
                
      
            <div class="form-group" >
                  <label class="control-label col-sm-3" for="idem id" id="label">Item ID :</label>
                  <div class="col-sm-4">
                        <input type="text"  class="form-control" placeholder="Enter Item ID"   id="itemid" name="itemid"  >
                  </div>
                     <label class="control-label col-sm-4"  id="iderror">*</label>
            </div>

        <div class="form-group">
                  <label class="control-label col-sm-3" for="Item name"  id="label" >Item Name :</label>
                  <div class="col-sm-4">
                    <input type="text" class="form-control" id="name"  placeholder="Enter Item Name" name="name"  onblur="checkname()">
                  </div>
            <label class="control-label col-sm-4" id="nameerror">*</label>
        </div>
        <div class="form-group">
              <label class="control-label col-sm-3" for="Quantity" id="label" > Quantity :</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" id="quantity" placeholder="Enter Only Digits" name="quantity" value="0" onblur="checkquantity()">
              </div>
            <label class="control-label col-sm-4" id="quantityerror">*</label>
            </div>
                    
         <div class="form-group">
              <label class="control-label col-sm-3" for="Seleing price" id="label" >Selling Price(per unit):</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" id="price" placeholder="Enter Only Digits(442.00)" name="price" onblur="checkprice()" >
            </div>
             <label class="control-label col-sm-4" id="priceerror">*</label>
        </div>

        <div class="form-group">
              <label class="control-label col-sm-3" for="height" id="label" >Height :</label>
              <div class="col-sm-4">
                 
                <input type="text" class="form-control" id="height" placeholder="Enter Height(3-7) " name="height"  onblur="checkheight()">
                 </div>
            <label class="control-label col-sm-4" id="heighterror">*</label>
        </div>
                    
        <div class="form-group">
              <label class="control-label col-sm-3" for="weight" id="label" >Weight (Gram):</label>
              <div class="col-sm-4">                
                <input type="text" class="form-control" id="weight" placeholder="Enter Only Digits" name="weight" onblur="checkweight()" >
                
            </div>
            <label class="control-label col-sm-4" id="weighterror">*</label>
        </div>
        
        <div class="form-group">
              <label class="control-label col-sm-3" for="address" id="label" >Item Picture :</label>
              <div class="col-sm-4">
                <input type="file"   placeholder="select Image" name="item_image" class ="button" required>
              </div>
            <label class="control-label col-sm-4" id="imageerror">*</label>
        </div>
        
        <div class="form-group">        
                  <div class="col-sm-offset-3 col-sm-10">
                        <input type="submit" name="submit" value="Save" class="button">
                        <input type="reset" value="clear" class="button">
                        
                  </div>
        </div>
                    
        </form>
                    

	</div>
  </div>
</div>
     

</body>
</html>

