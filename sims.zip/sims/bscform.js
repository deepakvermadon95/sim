function checkname()
        {
            var x=document.getElementById("name").value;
            var name=/^[A-Za-z ]{3,30}$/;
            if(name.test(x))
                {
            document.getElementById("nameerror").innerHTML="*";

                }
            else{
                 document.getElementById("nameerror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("name").value="";
                document.getElementById("name").focus();
            }
            
        }
function checkquantity()
        {
            var x=document.getElementById("quantity").value;
            var name=/^[0-9]{1,}$/;
            if(name.test(x))
                {
            document.getElementById("quantityerror").innerHTML="*";

                }
            else{
                 document.getElementById("quantityerror").innerHTML="Quantity never negative";
                document.getElementById("quantity").value="";
                document.getElementById("quantity").focus();
            }
            
        }
function checkprice()
        {
            var x=document.getElementById("price").value;
            var name=/^[1-9][0-9]{1,}[0-9.]{0,3}$/;
            
            if(name.test(x))
                {
            document.getElementById("priceerror").innerHTML="*";

                }
            else{
                 document.getElementById("priceerror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("price").value="";
                document.getElementById("price").focus();
            }
            
        }
function checkheight()
        {
            var x=document.getElementById("height").value;
            var name=/^[1-9][0-9]{0,}[-][0-9][01]{0,1}$/;
            
            if(name.test(x))
                {
            document.getElementById("heighterror").innerHTML="*";

                }
            else{
                 document.getElementById("heighterror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("height").value="";
                document.getElementById("height").focus();
            }
            
        }
function checkweight()
        {
            var x=document.getElementById("weight").value;
            var name=/^[1-9][0-9]{1,}$/;
            
            if(name.test(x))
                {
            document.getElementById("weighterror").innerHTML="*";

                }
            else{
                 document.getElementById("weighterror").innerHTML="Wrong Name Format Is Incorrect";
                document.getElementById("weight").value="";
                document.getElementById("weight").focus();
            }
            
        }

        function checkmobile()
        {
            var x=document.getElementById("number").value;
            var mobile=/^[6789][0-9]{9}$/;
            if(mobile.test(x))
                {
            document.getElementById("mobileerror").innerHTML="";

                }
            else{
                 document.getElementById("mobileerror").innerHTML="Wrong mobile number please check your self";
            }
            
        }
        function checkpassword()
        {
            var x=document.getElementById("password").value;
            var password=/^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,15}$/;
            if(password.test(x))
                {
            document.getElementById("passworderror").innerHTML="";

                }
            else{
                 document.getElementById("passworderror").innerHTML="there must be atleast one spacial charcter and one digits ";
                document.getElementById("password").value="";
                document.getElementById("password").focus();
            }
            
        }

function checkrepassword()
        {
            var x=document.getElementById("password").value;
            var y=document.getElementById("repassword").value;
            //var password=/^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,15}$/;
            if()
                {
            document.getElementById("passworderror").innerHTML="";

                }
            else{
                 document.getElementById("passworderror").innerHTML="there must be atleast one spacial charcter and one digits ";
                document.getElementById("password").value="";
                document.getElementById("password").focus();
            }
            
        }

        function checkmail()
        {
            
            var x=document.getElementById("email").value;
            var emailcheck=/^[a-z][a-z0-9_]{2,}@[a-z]{2,}[.][a-z.]{2,6}$/;
            if(emailcheck.test(x)){
                        document.getElementById("emailerror").innerHTML="";
                      }
            else{
                    document.getElementById("emailerror").innerHTML="wrong Email";
                    //document.getElementById("email").innerHTML="";
                    document.getElementById("email").focus();

            }
                
    
                
        }
                
            
    
