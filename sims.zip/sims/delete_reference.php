<?php
include 'connection.php';
session_start();
$tea_regno = $_SESSION['t_regno'];
$subject = str_replace('_',' ',$_GET['subject']);
$class = $_GET['class'];
$link = $_GET['link'];
$disc = $_GET['topic'];


$sql = "delete from reference where tea_regno='$tea_regno' and subject='$subject' and class='$class' and link='$link' and description='$disc';";

if(mysqli_query($con,$sql))
{
    header("location:welcome_teacher.php");
}else
        echo "deletion not done, something went wrong in delete_reference.php";

?>